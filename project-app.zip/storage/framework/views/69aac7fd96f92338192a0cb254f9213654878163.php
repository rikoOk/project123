

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">Login</div>
        <div class="card-body">

            <form action="<?php echo e(route('login')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <label>Email</label>
                <input type="email" name="email" id="email" class="form-control" required> </br>

                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control" required> </br>

                <input type="submit" value="Login" class="btn btn-primary">
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/contact/login.blade.php ENDPATH**/ ?>