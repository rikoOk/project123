
<?php $__env->startSection('content'); ?>



  
    <div class="card" style="box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); border-radius: 10px;">
        <div class="card-header" style="background-color: #f8f9fa; border-bottom: 1px solid #dee2e6; border-top-left-radius: 10px; border-top-right-radius: 10px;">
            <h3 class="card-title" style="margin: 0;">Register</h3>
        </div>
        <div class="card-body" style="padding: 20px;">
        
            <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>   
                <div class="form-group">
                    <label for="name">First Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter your first name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn btn-success btn-block" style="margin-top: 10px;">Register</button>
            </form>
            <div style="text-align: right; margin-top: -30px;">
                <a class="start-button" onclick="window.location.href = 'login';">I already have an account</a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/contact/create.blade.php ENDPATH**/ ?>