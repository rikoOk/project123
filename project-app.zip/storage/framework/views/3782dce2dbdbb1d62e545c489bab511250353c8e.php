
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-center mt-5">
        <div class="card shadow-sm" style="width: 90%; max-width: 1200px; border-radius: 0.5rem; background-color: #f8f9fa;">
            <div class="card-header text-white text-center" style="background-color: #6c757d; border-top-left-radius: 0.5rem; border-top-right-radius: 0.5rem;">
                <h2>Student Management</h2>
            </div>
            <div class="card-body p-4">
                <div class="d-flex justify-content-between mb-3">
                    <h4>Student List</h4>
                    <a href="<?php echo e(url('/student/create')); ?>" class="btn btn-success btn-sm" title="Add New Student">Add New</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead style="background-color: #343a40; color: white;">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Mobile</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->address); ?></td>
                                <td><?php echo e($item->mobile); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/student/' . $item->id)); ?>" title="View Student" class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</a>
                                    <a href="<?php echo e(url('/student/' . $item->id . '/edit')); ?>" title="Edit Student" class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</a>
                                    <form method="POST" action="<?php echo e(url('/student' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" class="btn btn-danger btn-sm" title="Delete Student" onclick="return confirm('Confirm delete?')"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/admin/index.blade.php ENDPATH**/ ?>