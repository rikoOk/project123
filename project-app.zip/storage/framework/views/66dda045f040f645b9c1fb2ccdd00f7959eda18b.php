
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-sm" style="width: 24rem; border-radius: 1rem; background-color: #f8f9fa;">
        <div class="card-header text-white text-center" style="background-color: #6c757d; border-top-left-radius: 1rem; border-top-right-radius: 1rem;">
            Create New Student
        </div>
        <div class="card-body p-4">
            <form action="<?php echo e(url('student')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter your name">
                </div>
                <div class="form-group mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" name="address" id="address" class="form-control" placeholder="Enter your address">
                </div>
                <div class="form-group mb-3">
                    <label for="mobile" class="form-label">Mobile</label>
                    <input type="text" name="mobile" id="mobile" class="form-control" placeholder="Enter your mobile number">
                </div>
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/students/create.blade.php ENDPATH**/ ?>