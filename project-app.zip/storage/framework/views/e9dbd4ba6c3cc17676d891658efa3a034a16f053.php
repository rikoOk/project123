<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Navbar with Back Button</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
    .navbar-custom {
      background-color: #6d7277; /* Warna latar belakang navbar */
    }
    .navbar-brand {
      font-size: 24px;
      font-weight: bold;
    }
    .nav-link {
      font-size: 18px;
    }

    .start-button {
            padding: 10px 12px; /* Ubah ukuran padding */
            font-size: 18px; /* Ubah ukuran font */
            background-color: #777777; /* Warna latar belakang */
            color: #535353; /* Warna teks */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s; /* Efek transisi saat dihover */
        }
        .start-button:hover {
            background-color: #45a049; /* Warna latar belakang saat dihover */
        }
    .post {
      background-color: #f8f9fa;
      padding: 20px;
      margin-top: 20px;
      border-radius: 10px;
    }
    .post h2 {
      font-size: 24px;
      margin-bottom: 10px;
    }
    .post p {
      font-size: 18px;
    }
    .header-img {
      position: relative;
      width: 100%;
      height: 500px; /* Sesuaikan tinggi gambar sesuai kebutuhan */
      overflow: hidden;
    }
    .header-img img {
      width: 100%;
      height: auto;
      position: absolute;
      top: -200px;
      left: 0;
      z-index: -1;
    }
    .header-img:after {
      content: '';
      position: absolute;
      width: 100%;
      height: 100%;
      background: linear-gradient(to bottom, rgba(255,255,255,0) 0%,rgba(255,255,255,1) 100%);
      z-index: 1;
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
      <button onclick="history.back()" class="btn btn-light me-3"><-</button>
      <a class="navbar-brand" href="#">INI Web :)</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Services</a>
          </li>
          <li class="nav-item">
            <button class="start-button" onclick="window.location.href = 'login';">MULAI</button>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="header-img">
    <img src="https://4.bp.blogspot.com/-aWtBXqndW3U/XLYhZrsClwI/AAAAAAAAEOc/18TjlBqCoCUGXL63sOW__3I4amtk5Sx6QCEwYBhgL/s1600/panorama%2Bpemandangan%2Bindah%2Bgunung-min.jpg" alt="Header Image">
  </div>

  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="post mb-3 rounded">
          <h6>Postingan Pertama</h6>
          <h6>Ini adalah deskripsi dari postingan pertama. Anda dapat menambahkan konten di sini.</h6>
        </div>
      </div>
      <div class="col-md-6">
        <div class="post mb-3 rounded">
          <h6>Postingan Kedua</h6>
          <h6>Ini adalah deskripsi dari postingan kedua. Anda juga dapat menambahkan konten di sini.</h6>
        </div>
      </div>
      <div class="col-md-6">
        <div class="post mb-3 rounded">
          <h6>Postingan Ketiga</h6>
          <h6>Ini adalah deskripsi dari postingan ketiga. Anda juga dapat menambahkan konten di sini.</h6>
        </div>
      </div>
      <div class="col-md-6">
        <div class="post mb-3 rounded">
          <h6>Postingan Keempat</h6>
          <h6>Ini adalah deskripsi dari postingan keempat. Anda juga dapat menambahkan konten di sini.</h6>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS bundle -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-qLAO2VmygrLONde94iEcrjO3wVr0QwnZnG0fN5O5z5VdHgJjLLYjGy16m7KtJcQ1" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\project-app\resources\views/contact/thanks.blade.php ENDPATH**/ ?>