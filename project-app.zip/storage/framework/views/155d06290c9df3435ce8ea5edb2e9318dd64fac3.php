
<?php $__env->startSection('content'); ?>

<div class="card" style="margin:20px;">
  <div class="card-header bg-primary text-white">Students Page</div>
  <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : <?php echo e($students->name); ?></h5>
            <p class="card-text">Address : <?php echo e($students->address); ?></p>
            <p class="card-text">Mobile : <?php echo e($students->mobile); ?></p>
            <a href="<?php echo e(url('/student/' . $students->id . '/edit')); ?>" class="btn btn-primary mr-2">Edit</a>
            <form action="<?php echo e(url('/student/' . $students->id)); ?>" method="post" class="d-inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this student?')">Delete</button>
            </form>
        </div>
    </hr>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/students/show.blade.php ENDPATH**/ ?>