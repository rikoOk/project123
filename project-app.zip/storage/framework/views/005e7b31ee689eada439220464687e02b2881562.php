
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-sm" style="width: 40%; border-radius: 0.25rem; background-color: #f8f9fa; margin: 20px;">
        <div class="card-header text-white text-center" style="background-color: #6c757d; border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">
            Edit Student
        </div>
        <div class="card-body p-4">
            <form action="<?php echo e(url('student/' . $students->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PATCH"); ?>
                <input type="hidden" name="id" id="id" value="<?php echo e($students->id); ?>" />
                <div class="form-group mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" id="name" value="<?php echo e($students->name); ?>" class="form-control" placeholder="Enter your name">
                </div>
                <div class="form-group mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" name="address" id="address" value="<?php echo e($students->address); ?>" class="form-control" placeholder="Enter your address">
                </div>
                <div class="form-group mb-3">
                    <label for="mobile" class="form-label">Mobile</label>
                    <input type="text" name="mobile" id="mobile" value="<?php echo e($students->mobile); ?>" class="form-control" placeholder="Enter your mobile number">
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project-app\resources\views/students/edit.blade.php ENDPATH**/ ?>