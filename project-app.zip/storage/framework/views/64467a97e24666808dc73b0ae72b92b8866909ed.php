<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Management</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="student">Student Management</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">Welcome, Admin</a>
                </li>
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item mr-3">
                        <a class="btn btn-sm btn-success" href="<?php echo e(url('/student/create')); ?>">
                            <i class="fas fa-plus-circle mr-1"></i>Add New Student
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-sm btn-danger" href="<?php echo e(url('/logout')); ?>">
                            <i class="fas fa-sign-out-alt mr-1"></i>Logout
                        </a>
                    </li>
                </ul>
                
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white text-center">
            <h2>Daftar siswa</h2>
        </div>
        <div class="card-body p-4">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Nama siswa</th>
                            <th>Alamat</th>
                            <th>No.tlp</th>
                            <th>Foto</th> <!-- New column for the photo -->
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->address); ?></td>
                            <td><?php echo e($item->mobile); ?></td>
                            <td>
                                <?php if($item->photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $item->photo)); ?>" alt="<?php echo e($item->name); ?>" width="50" height="50">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/default-photo.png')); ?>" alt="Default Photo" width="50" height="50">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/student/' . $item->id)); ?>" title="View Student" class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</a>
                                <form method="POST" action="<?php echo e(url('/student' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min
<?php /**PATH C:\xampp\htdocs\project-app\resources\views/students/index.blade.php ENDPATH**/ ?>