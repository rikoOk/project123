@extends('layout')
@section('content')
  
    <div class="card">
        <div class="card-header">Login Form</div>
        <div class="card-body"> 
        
            <form action="{{ route('check') }}" method="post">
                {!! csrf_field() !!}   

                <label>Email</label>
                <input type="email" name="email" id="email" class="form-control"> </br>

                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control"> </br>

                <div class="d-flex justify-content-between">
                    <input type="submit" value="Login" class="btn btn-success"> 
                    <a href="{{ route('register') }}
                    ">Belum Punya Akun? Daftar</a>
                </div>
            </form>
        </div>
    </div>

@stop
