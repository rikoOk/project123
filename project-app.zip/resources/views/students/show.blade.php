@extends('students.layout')
@section('content')

<div class="card" style="margin:20px;">
  <div class="card-header bg-primary text-white">Students Page</div>
  <div class="card-body">
        <div class="card-body">
            <h5 class="card-title">Name : {{ $students->name }}</h5>
            <p class="card-text">Address : {{ $students->address }}</p>
            <p class="card-text">Mobile : {{ $students->mobile }}</p>
            <a href="{{ url('/student/' . $students->id . '/edit') }}" class="btn btn-primary mr-2">Edit</a>
            <form action="{{ url('/student/' . $students->id) }}" method="post" class="d-inline">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this student?')">Delete</button>
            </form>
        </div>
    </hr>
  </div>
</div>

@endsection
