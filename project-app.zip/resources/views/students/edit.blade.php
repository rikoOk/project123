@extends('students.layout')
@section('content')

<div class="d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow-sm" style="width: 40%; border-radius: 0.25rem; background-color: #f8f9fa; margin: 20px;">
        <div class="card-header text-white text-center" style="background-color: #6c757d; border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem;">
            Edit Student
        </div>
        <div class="card-body p-4">
            <form action="{{ url('student/' . $students->id) }}" method="post">
                @csrf
                @method("PATCH")
                <input type="hidden" name="id" id="id" value="{{ $students->id }}" />
                <div class="form-group mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" name="name" id="name" value="{{ $students->name }}" class="form-control" placeholder="Enter your name">
                </div>
                <div class="form-group mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" name="address" id="address" value="{{ $students->address }}" class="form-control" placeholder="Enter your address">
                </div>
                <div class="form-group mb-3">
                    <label for="mobile" class="form-label">Mobile</label>
                    <input type="text" name="mobile" id="mobile" value="{{ $students->mobile }}" class="form-control" placeholder="Enter your mobile number">
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

@stop
